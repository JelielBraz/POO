public class lista3_2 {
}

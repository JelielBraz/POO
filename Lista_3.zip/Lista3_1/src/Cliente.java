public class Cliente {
    private String nome;
    private String cpf;



    public Cliente(String name, String cpf){
        this.nome  = name;
        this.cpf = cpf;
    }




}

